import Mock from 'mockjs'

// 商品分页筛选接口
Mock.mock('/api/goods/list', 'get', (req) => {
    const urlParams = new URLSearchParams(req.url.split('?')[1])
    const page = Number(urlParams.get('page')) || 1
    const pageSize = Number(urlParams.get('pageSize')) || 10
    const categoryId = urlParams.get('categoryId')

    const mockData = Mock.mock({
        [`list|100`]: [{
            id: '@id',
            title: '@cword(6,12)',
            price: '@float(10,999,2)',
            categoryId: '@integer(1,4)',
            img: '@image(100x100)'
        }]
    })

    let list = mockData.list
    if (categoryId) {
        list = list.filter(item => item.categoryId == categoryId)
    }
    const total = list.length
    const start = (page - 1) * pageSize
    const pageList = list.slice(start, start + pageSize)

    return {
        code: 200,
        data: {
            list: pageList,
            total,
            page,
            pageSize
        },
        msg: 'success'
    }
})

// 商品分类接口
Mock.mock('/api/category/list', 'get', {
    code: 200,
    data: [
        { id: '', name: '全部分类' },
        { id: 1, name: '手机数码' },
        { id: 2, name: '家用电器' },
        { id: 3, name: '服饰鞋包' },
        { id: 4, name: '食品生鲜' }
    ]
})