import request from '../utils/request'

// 获取商品分页列表
export function getGoodsList(params) {
    return request({
        url: '/goods/list',
        method: 'get',
        params
    })
}

// 获取分类下拉选项
export function getCategoryList() {
    return request({
        url: '/category/list',
        method: 'get'
    })
}