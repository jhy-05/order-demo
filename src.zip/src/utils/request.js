import axios from 'axios'

const service = axios.create({
    baseURL: '/api',
    timeout: 8000
})

// 请求拦截器
service.interceptors.request.use(config => {
    return config
}, err => Promise.reject(err))

// 响应拦截器
service.interceptors.response.use(res => {
    return res.data
}, err => {
    alert('请求失败：' + err.message)
    return Promise.reject(err)
})

export default service