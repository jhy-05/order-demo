import request from '../utils/request'
export function getGoodsList(params) {
    return request({ url: '/goods/list', method: 'get', params })
}
export function getCategoryList() {
    return request({ url: '/category/list', method: 'get' })
}