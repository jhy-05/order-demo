<template>
  <div class="goods-box">
    <div class="filter">
      <span>商品分类：</span>
      <select v-model="searchParams.categoryId" @change="getList">
        <option v-for="item in categoryList" :key="item.id" :value="item.id">
          {{ item.name }}
        </option>
      </select>
    </div>
    <table border="1" width="100%" style="margin:10px 0">
      <thead>
        <tr>
          <th>ID</th>
          <th>商品名称</th>
          <th>价格</th>
          <th>分类ID</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in goodsList" :key="item.id">
          <td>{{ item.id }}</td>
          <td>{{ item.title }}</td>
          <td>¥{{ item.price }}</td>
          <td>{{ item.categoryId }}</td>
        </tr>
      </tbody>
    </table>
    <div class="page">
      <button @click="prevPage" :disabled="searchParams.page === 1">上一页</button>
      <span>当前第{{ searchParams.page }}页 / 共{{ total }}条</span>
      <button @click="nextPage" :disabled="searchParams.page * searchParams.pageSize >= total">下一页</button>
    </div>
  </div>
</template>
<script setup>
import { ref, reactive, onMounted } from 'vue'
import { getGoodsList, getCategoryList } from '../api/goods'
const searchParams = reactive({ page: 1, pageSize: 10, categoryId: '' })
const goodsList = ref([])
const categoryList = ref([])
const total = ref(0)
async function getList() {
  const res = await getGoodsList(searchParams)
  if (res.code === 200) {
    goodsList.value = res.data.list
    total.value = res.data.total
  }
}
async function getCategory() {
  const res = await getCategoryList()
  if (res.code === 200) categoryList.value = res.data
}
function prevPage() {
  searchParams.page--
  getList()
}
function nextPage() {
  searchParams.page++
  getList()
}
onMounted(() => {
  getCategory()
  getList()
})
</script>