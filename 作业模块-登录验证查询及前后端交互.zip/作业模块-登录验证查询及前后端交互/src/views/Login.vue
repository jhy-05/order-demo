<template>
  <div class="login">
    <h2>电商平台登录</h2>
    <div>
      <label>账号：</label>
      <input v-model="form.username" placeholder="admin" />
    </div>
    <div style="margin:10px 0">
      <label>密码：</label>
      <input v-model="form.password" type="password" placeholder="123456" />
    </div>
    <button @click="handleLogin">登录</button>
  </div>
</template>
<script setup>
import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import { login } from '../api/user'
const router = useRouter()
const form = reactive({
  username: '',
  password: ''
})
async function handleLogin() {
  const res = await login(form)
  if (res.code === 200) {
    // 存储token本地持久化
    localStorage.setItem('token', res.data.token)
    alert('登录成功')
    // 跳转到商品页面
    router.push('/goods')
  }
}
</script>