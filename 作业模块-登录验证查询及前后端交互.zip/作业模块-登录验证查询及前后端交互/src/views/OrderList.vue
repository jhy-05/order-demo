<template>
  <div class="order">
    <h3>我的订单列表</h3>
    <table border="1" width="100%">
      <thead>
        <tr>
          <th>订单号</th>
          <th>商品名称</th>
          <th>订单金额</th>
          <th>订单状态</th>
          <th>创建时间</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in orderList" :key="item.orderId">
          <td>{{ item.orderId }}</td>
          <td>{{ item.goodsName }}</td>
          <td>¥{{ item.price }}</td>
          <td>{{ item.status }}</td>
          <td>{{ item.createTime }}</td>
        </tr>
      </tbody>
    </table>
    <div style="margin-top:10px">
      <button @click="prev" :disabled="pageParams.page === 1">上一页</button>
      <span>第{{ pageParams.page }}页 / 共{{ total }}条</span>
      <button @click="next" :disabled="pageParams.page * pageParams.pageSize >= total">下一页</button>
    </div>
  </div>
</template>
<script setup>
import { ref, reactive, onMounted } from 'vue'
import { getOrderList } from '../api/order'
const pageParams = reactive({
  page: 1,
  pageSize: 10
})
const orderList = ref([])
const total = ref(0)
async function loadOrder() {
  const res = await getOrderList(pageParams)
  if (res.code === 200) {
    orderList.value = res.data.list
    total.value = res.data.total
  }
}
function prev() {
  pageParams.page--
  loadOrder()
}
function next() {
  pageParams.page++
  loadOrder()
}
onMounted(() => loadOrder())
</script>