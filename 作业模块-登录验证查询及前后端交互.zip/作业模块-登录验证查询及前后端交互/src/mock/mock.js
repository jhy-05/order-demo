import Mock from 'mockjs'

// 1.登录接口
Mock.mock('/api/user/login', 'post', req => {
    const body = JSON.parse(req.body)
    const { username, password } = body
    if (username === 'admin' && password === '123456') {
        return {
            code: 200,
            data: {
                token: 'admin-token-20260616',
                nickname: '管理员'
            },
            msg: '登录成功'
        }
    } else {
        return { code: 400, msg: '账号或密码错误' }
    }
})

// 2.商品分页筛选（复用之前）
Mock.mock('/api/goods/list', 'get', req => {
    const urlParams = new URLSearchParams(req.url.split('?')[1])
    const page = Number(urlParams.get('page')) || 1
    const pageSize = Number(urlParams.get('pageSize')) || 10
    const categoryId = urlParams.get('categoryId')
    const mockData = Mock.mock({
        [`list|100`]: [{
            id: '@id', title: '@cword(6,12)', price: '@float(10,999,2)', categoryId: '@integer(1,4)'
        }]
    })
    let list = mockData.list
    if (categoryId) list = list.filter(i => i.categoryId == categoryId)
    const total = list.length
    const pageList = list.slice((page - 1) * pageSize, page * pageSize)
    return { code: 200, data: { list: pageList, total, page, pageSize } }
})

Mock.mock('/api/category/list', 'get', {
    code: 200,
    data: [
        { id: '', name: '全部分类' },
        { id: 1, name: '手机数码' },
        { id: 2, name: '家用电器' },
        { id: 3, name: '服饰鞋包' },
        { id: 4, name: '食品生鲜' }
    ]
})

// 3.订单列表接口（需要token鉴权）
Mock.mock('/api/order/list', 'get', req => {
    // 无token返回401
    const token = req.headers.authorization
    if (!token) return { code: 401, msg: '请先登录' }
    const urlParams = new URLSearchParams(req.url.split('?')[1])
    const page = Number(urlParams.get('page')) || 1
    const pageSize = Number(urlParams.get('pageSize')) || 10
    const orderData = Mock.mock({
        [`list|35`]: [{
            orderId: '@id',
            goodsName: '@cword(4,8)',
            price: '@float(20,1000,2)',
            status: '@pick(["待付款","已付款","已发货","已完成"])',
            createTime: '@datetime'
        }]
    })
    const total = orderData.list.length
    const start = (page - 1) * pageSize
    const pageList = orderData.list.slice(start, start + pageSize)
    return {
        code: 200,
        data: { list: pageList, total, page, pageSize }
    }
})