import axios from 'axios'

const service = axios.create({
    baseURL: '/api',
    timeout: 8000
})

// 请求拦截：自动带上本地token
service.interceptors.request.use(config => {
    const token = localStorage.getItem('token')
    if (token) {
        config.headers.Authorization = `Bearer ${token}`
    }
    return config
}, err => Promise.reject(err))

// 响应拦截：token失效跳登录
service.interceptors.response.use(res => {
    return res.data
}, err => {
    const msg = err.response?.data?.msg || '请求失败'
    alert(msg)
    // 401=未登录/token过期
    if (err.response?.status === 401) {
        localStorage.removeItem('token')
        location.href = '/login'
    }
    return Promise.reject(err)
})

export default service